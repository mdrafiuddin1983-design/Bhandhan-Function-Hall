# Function Hall Booking, Management & Event Services Platform
## Architecture Overview — Phase 1 Foundation

## 1. Stack decision (reasonable defaults — swap freely)

| Layer | Choice | Why |
|---|---|---|
| API | Node.js + Express (TypeScript) | Simple, huge ecosystem, easy for a small team to maintain |
| DB | PostgreSQL | Native support for row locks, exclusion constraints, JSONB — critical for zero-double-booking |
| ORM | Prisma (or raw SQL for the booking engine) | Prisma for CRUD, **raw SQL inside the booking transaction** — ORMs hide the locking behavior we need to control |
| Auth | JWT (access + refresh) + OTP (phone) via a provider (MSG91/Twilio) | Role-based, standard for India-first products |
| File storage | S3-compatible bucket (hall photos/videos) | Cheap, CDN-friendly |
| Payments | Razorpay or Cashfree (marketplace/route split-settlement product) | Both support UPI + split settlement to hall owners, which Section 21 requires |
| Notifications | WhatsApp Business API (via a BSP like Gupshup/Interakt) + SMS + email (SES) + push (FCM) | |
| Mobile apps | React Native (one codebase → iOS + Android), consuming the same REST API | Fastest path to both stores; native Swift/Kotlin only if you need deep platform features later |
| AI chat | Retrieval-augmented agent calling read-only "tool" endpoints (availability, booking status, FAQ) — never allowed to write to bookings/payments directly | Matches Section 23's "must never invent availability/prices/status" rule |
| AI voice | Same tool-calling agent behind a telephony provider (Exotel/Twilio Voice) + speech-to-text/text-to-speech | High-risk actions (refunds, cash adjustments) routed to a human queue, per Section 24 |

## 2. Non-negotiable rule: zero double booking

Booking safety is enforced at **three layers**, not just the frontend:

1. **Frontend**: disables already-booked dates (UX only, never trusted).
2. **API transaction**: every booking write happens inside a single DB transaction that takes a row lock on the hall+date before checking availability.
3. **Database constraint**: a PostgreSQL `EXCLUDE` constraint on `(hall_id, daterange(event_date, event_date, '[]'))` for any booking in `HELD / PAYMENT_PENDING / CONFIRMED / PARTIALLY_PAID / FULLY_PAID` — this makes a true double-booking **impossible even if application code has a bug**, because Postgres itself rejects the second insert.

See `db/schema.sql` for the actual constraint and `server/src/routes/bookings.ts` for the transaction.

## 3. Core entity-relationship diagram (Phase 1–4 scope)

```mermaid
erDiagram
    OWNERS ||--o{ FUNCTION_HALLS : owns
    FUNCTION_HALLS ||--o{ HALL_IMAGES : has
    FUNCTION_HALLS ||--o{ HALL_SERVICES : offers
    SERVICES ||--o{ HALL_SERVICES : "used in"
    FUNCTION_HALLS ||--o{ BOOKINGS : "booked for"
    CUSTOMERS ||--o{ BOOKINGS : makes
    EVENT_TYPES ||--o{ BOOKINGS : categorizes
    BOOKINGS ||--o{ BOOKING_SERVICES : includes
    BOOKINGS ||--o{ PAYMENTS : has
    BOOKINGS ||--o{ AUDIT_LOGS : "logged by"
    MANAGERS ||--o{ FUNCTION_HALLS : "assigned to"
    PAYMENTS ||--o{ CASH_COLLECTIONS : "when cash"

    OWNERS { uuid id PK }
    FUNCTION_HALLS { uuid id PK, uuid owner_id FK, text name, text city, int capacity }
    BOOKINGS { uuid id PK, uuid hall_id FK, uuid customer_id FK, date event_date, text status, text payment_status }
    PAYMENTS { uuid id PK, uuid booking_id FK, numeric amount, text method, text status }
    CASH_COLLECTIONS { uuid id PK, uuid payment_id FK, uuid manager_id FK, text verification_status }
```

Full 30+ table schema (invitations, taxi, settlements, AI knowledge base, etc.) follows the same pattern and is added phase-by-phase — starting narrow avoids building unused tables before the workflows they support are designed.

## 4. Booking state machine (Section 5)

```
AVAILABLE → TEMPORARILY_HELD → PAYMENT_PENDING → CONFIRMED → COMPLETED
                   ↓ (timeout)         ↓ (fail)        ↓
                EXPIRED           CANCELLED        CANCELLED
```
Status fields are **separate** per Section 40: `booking_status`, `payment_status`, `cash_verification_status`, `settlement_status`, `event_status` each live on their own column — never collapsed into one enum.

## 5. Phased delivery plan

| Phase | Scope | Status |
|---|---|---|
| 1 | Auth + roles + DB foundation | Built |
| 2 | Function hall management (CRUD, photos, services) | Built |
| 3 | Availability calendar | Built |
| 4 | Booking engine (zero-double-booking transaction) | Built |
| 5 | Payment gateway integration (advance/full, webhook-verified confirm) | Built — needs your Razorpay/Cashfree keys to actually run |
| 6 | Manual/cash booking + reconciliation (OTP verification, shift open/declare/reconcile, discrepancy report) | **Built this pass** |
| 7 | Notifications (push/WhatsApp/SMS/email, balance-due reminder scheduler) | **Built this pass** — provider adapters are stubs, need your WhatsApp BSP/SMS/email accounts |
| 8 | Owner/Manager dashboards | **Started this pass** (owner summary API only — no UI yet, no manager dashboard yet) |
| 9 | Reports & analytics (exports, deeper breakdowns) | Next |
| 10 | Digital invitations | Next |
| 11 | AI chat support | Next |
| 12 | AI voice agent | Needs telephony provider |
| 13 | Taxi/ride marketplace | Next |
| 14 | Customer + Manager mobile apps (React Native) | Next — consumes the same API |

## 7. What's actually running vs. stubbed, as of this pass
- **Real logic, ready to connect to real accounts:** booking engine, payment webhook verification, cash OTP + shift reconciliation, notification dedupe/retry logic, balance-reminder scheduling.
- **Stubbed, needs your credentials:** WhatsApp (Gupshup/Interakt), SMS (MSG91/Twilio), email (SES/SendGrid) — see `server/src/services/notifications.ts`, the four provider functions at the bottom. Payment gateway needs real Razorpay/Cashfree keys.
- **Not started:** owner/manager dashboard UI (only the API exists), reports/exports, invitations, AI chat/voice, taxi module, mobile apps.


**Website (Section 32)** is prototyped this pass as a static responsive front-end (`website/`) so you can see the UX direction — it's currently wired to sample data, not the live API.

## 6. What I need from you to move past Phase 4
- A Razorpay or Cashfree business account (for split-settlement payouts to owners)
- A WhatsApp BSP account (Gupshup/Interakt) + SMS provider (MSG91) for notifications
- Where this will be hosted (Render/Railway/AWS/your own server) so I can tailor deployment config
- Confirmation this Node/Postgres/React Native stack works for your team, or a different preference
