import express from "express";
import cors from "cors";
import { authRouter } from "./routes/auth";
import { hallsRouter } from "./routes/halls";
import { bookingsRouter } from "./routes/bookings";
import { paymentsRouter } from "./routes/payments";
import { manualBookingsRouter } from "./routes/manualBookings";
import { cashRouter } from "./routes/cash";
import { ownerRouter } from "./routes/owner";
import { ownerAccountsRouter } from "./routes/ownerAccounts";
import { startBalanceReminderJob } from "./jobs/balanceReminders";

const app = express();
app.use(cors()); // demo: open CORS. In production, restrict to your real website's domain.

// Razorpay webhook needs the raw body for signature verification —
// register it BEFORE the global express.json() body parser.
app.use("/api/payments/webhook", express.raw({ type: "application/json" }), (req, _res, next) => {
  req.body = JSON.parse(req.body.toString());
  next();
});
app.use(express.json());

app.use("/api/auth", authRouter);
app.use("/api/halls", hallsRouter);
app.use("/api/bookings", bookingsRouter);
app.use("/api/payments", paymentsRouter);
app.use("/api/manual-bookings", manualBookingsRouter);
app.use("/api/cash", cashRouter);
app.use("/api/owner", ownerRouter);
app.use("/api/owner-accounts", ownerAccountsRouter);

const port = process.env.PORT || 4000;
app.listen(port, () => {
  console.log(`API listening on :${port}`);
  startBalanceReminderJob(); // daily 9am balance-due reminder sweep
});
