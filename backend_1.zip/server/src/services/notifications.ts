import { pool } from "../db/pool";

/**
 * One call site for every outbound message in the platform.
 * Swap the four provider functions at the bottom for your actual
 * accounts (Gupshup/Interakt for WhatsApp, MSG91/Twilio for SMS,
 * SES/SendGrid for email, FCM for push) — nothing else needs to change.
 */

type Channel = "PUSH" | "WHATSAPP" | "SMS" | "EMAIL";

interface SendArgs {
  userId: string;
  bookingId?: string;
  eventKey: string; // e.g. 'BOOKING_CONFIRMED', 'BALANCE_REMINDER'
  vars: Record<string, string | number>;
  channels?: Channel[]; // defaults to every channel that has a template + the user has contact info for
}

function render(template: string, vars: Record<string, string | number>) {
  return template.replace(/{{(\w+)}}/g, (_, key) => String(vars[key] ?? ""));
}

export async function sendNotification({ userId, bookingId, eventKey, vars, channels }: SendArgs) {
  const { rows: userRows } = await pool.query(`SELECT phone, email FROM users WHERE id = $1`, [userId]);
  const user = userRows[0];
  if (!user) return;

  const { rows: templates } = await pool.query(
    `SELECT * FROM notification_templates WHERE event_key = $1 AND is_active = TRUE
     ${channels ? `AND channel = ANY($2)` : ""}`,
    channels ? [eventKey, channels] : [eventKey]
  );

  for (const tpl of templates) {
    // Dedupe: the DB's partial unique index (idx_notifications_dedupe) is the
    // real backstop — this insert will simply fail harmlessly if a SENT/PENDING
    // row already exists for this booking+event+channel.
    const body = render(tpl.body, vars);
    const subject = tpl.subject ? render(tpl.subject, vars) : undefined;

    let record;
    try {
      const { rows } = await pool.query(
        `INSERT INTO notifications (user_id, booking_id, event_key, channel, status)
         VALUES ($1,$2,$3,$4,'PENDING') RETURNING *`,
        [userId, bookingId ?? null, eventKey, tpl.channel]
      );
      record = rows[0];
    } catch (err: any) {
      if (err.code === "23505") continue; // already sent/pending — skip silently
      throw err;
    }

    try {
      let providerMessageId: string;
      if (tpl.channel === "WHATSAPP") {
        if (!user.phone) throw new Error("no_contact");
        providerMessageId = await sendWhatsApp(user.phone, body);
      } else if (tpl.channel === "SMS") {
        if (!user.phone) throw new Error("no_contact");
        providerMessageId = await sendSMS(user.phone, body);
      } else if (tpl.channel === "EMAIL") {
        if (!user.email) throw new Error("no_contact");
        providerMessageId = await sendEmail(user.email, subject ?? "Bandhan Function Hall", body);
      } else {
        providerMessageId = await sendPush(userId, body);
      }

      await pool.query(
        `UPDATE notifications SET status='SENT', provider_message_id=$2, sent_at=now() WHERE id=$1`,
        [record.id, providerMessageId]
      );
    } catch (err: any) {
      const status = err.message === "no_contact" ? "SKIPPED_NO_CONTACT" : "FAILED";
      await pool.query(
        `UPDATE notifications SET status=$2, error_message=$3 WHERE id=$1`,
        [record.id, status, String(err.message).slice(0, 500)]
      );
      // Deliberately don't throw — one channel failing (e.g. WhatsApp down)
      // must never block the others (SMS/email) from still going out.
    }
  }
}

// ---- Provider adapters — replace with real SDK calls ----

async function sendWhatsApp(phone: string, body: string): Promise<string> {
  // Example (Gupshup): POST https://api.gupshup.io/wa/api/v1/msg
  // with your API key, source number, destination=phone, message=body
  console.log(`[stub] WhatsApp → ${phone}: ${body}`);
  return "stub-wa-id";
}

async function sendSMS(phone: string, body: string): Promise<string> {
  // Example (MSG91): POST https://api.msg91.com/api/v5/flow/ with your template + phone
  console.log(`[stub] SMS → ${phone}: ${body}`);
  return "stub-sms-id";
}

async function sendEmail(email: string, subject: string, body: string): Promise<string> {
  // Example (SES/SendGrid): send via their SDK with subject/body
  console.log(`[stub] Email → ${email}: ${subject} — ${body}`);
  return "stub-email-id";
}

async function sendPush(userId: string, body: string): Promise<string> {
  // Example (FCM): look up the user's device tokens, send via firebase-admin
  console.log(`[stub] Push → user ${userId}: ${body}`);
  return "stub-push-id";
}
