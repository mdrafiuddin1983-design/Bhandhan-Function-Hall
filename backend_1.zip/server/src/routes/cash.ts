import { Router } from "express";
import crypto from "crypto";
import { pool } from "../db/pool";
import { requireRole } from "./auth";
import { sendNotification } from "../services/notifications";

export const cashRouter = Router();

/**
 * Step 1: after recording cash (manualBookings.ts), send a 6-digit OTP to
 * the customer's phone. The manager reads it back from the customer to
 * prove the money actually changed hands — this is what stops "recorded
 * in software" from silently standing in for "cash actually received."
 */
cashRouter.post("/:cashCollectionId/send-otp", requireRole("MANAGER"), async (req, res) => {
  const otp = String(Math.floor(100000 + Math.random() * 900000));
  const otpHash = crypto.createHash("sha256").update(otp).digest("hex");

  const { rows } = await pool.query(
    `UPDATE cash_collections
     SET otp_code_hash = $2, otp_expires_at = now() + interval '10 minutes'
     WHERE id = $1
     RETURNING payment_id`,
    [req.params.cashCollectionId, otpHash]
  );
  if (!rows[0]) return res.status(404).json({ error: "Cash record not found" });

  const payment = (await pool.query(`SELECT booking_id FROM payments WHERE id = $1`, [rows[0].payment_id])).rows[0];
  const booking = (await pool.query(`SELECT customer_id FROM bookings WHERE id = $1`, [payment.booking_id])).rows[0];

  // TODO: in production, send the raw OTP directly, not through the
  // templated sendNotification path (avoid storing the OTP itself in notifications).
  console.log(`[stub] Cash verification OTP for booking ${payment.booking_id}: ${otp}`);

  res.json({ message: "OTP sent to customer" });
});

/** Step 2: manager enters the OTP the customer read out to them. */
cashRouter.post("/:cashCollectionId/verify-otp", requireRole("MANAGER"), async (req, res) => {
  const { otp } = req.body;
  const otpHash = crypto.createHash("sha256").update(otp).digest("hex");

  const { rows } = await pool.query(
    `UPDATE cash_collections
     SET otp_verified = TRUE
     WHERE id = $1 AND otp_code_hash = $2 AND otp_expires_at > now()
     RETURNING *`,
    [req.params.cashCollectionId, otpHash]
  );
  if (!rows[0]) return res.status(400).json({ error: "Invalid or expired OTP" });

  await pool.query(
    `INSERT INTO audit_logs (action, new_value) VALUES ('Cash payment customer-verified', $1)`,
    [JSON.stringify(rows[0])]
  );

  res.json({ verified: true });
});

/** Manager opens a shift with a declared opening cash float. */
cashRouter.post("/shifts/open", requireRole("MANAGER"), async (req: any, res) => {
  const { hall_id, opening_cash } = req.body;
  const { rows } = await pool.query(
    `INSERT INTO cash_shifts (manager_id, hall_id, shift_date, opening_cash)
     VALUES ($1,$2,CURRENT_DATE,$3)
     ON CONFLICT (manager_id, hall_id, shift_date) DO UPDATE SET opening_cash = EXCLUDED.opening_cash
     RETURNING *`,
    [req.user.sub, hall_id, opening_cash]
  );
  res.status(201).json(rows[0]);
});

/**
 * Manager declares what they're handing over at end of shift.
 * `expected` is computed live from actual cash_collections rows tied to
 * this shift — the manager's declaration can never overwrite it.
 */
cashRouter.post("/shifts/:shiftId/declare", requireRole("MANAGER"), async (req, res) => {
  const { declared_closing } = req.body;

  const shift = (await pool.query(`SELECT * FROM cash_shifts WHERE id = $1`, [req.params.shiftId])).rows[0];
  if (!shift) return res.status(404).json({ error: "Shift not found" });

  const { rows: collected } = await pool.query(
    `SELECT COALESCE(SUM(declared_amount),0) AS total
     FROM cash_collections WHERE shift_id = $1`,
    [req.params.shiftId]
  );
  const expected = Number(shift.opening_cash) + Number(collected[0].total);

  await pool.query(
    `UPDATE cash_shifts SET declared_closing = $2, status = 'DECLARED' WHERE id = $1`,
    [req.params.shiftId, declared_closing]
  );

  const difference = Number(declared_closing) - expected;
  res.json({ expected_closing: expected, declared_closing, difference });
});

/**
 * Owner reviews the shift. A mismatch is surfaced, never silently accepted —
 * matches the rule that the system must never claim cash was received just
 * because a manager typed a number.
 */
cashRouter.post("/shifts/:shiftId/reconcile", requireRole("OWNER", "SUPER_ADMIN"), async (req: any, res) => {
  const { rows } = await pool.query(
    `UPDATE cash_shifts
     SET status = 'RECONCILED', reconciled_by = $2, reconciled_at = now()
     WHERE id = $1 RETURNING *`,
    [req.params.shiftId, req.user.sub]
  );
  if (!rows[0]) return res.status(404).json({ error: "Shift not found" });

  await pool.query(
    `INSERT INTO audit_logs (user_id, role, action, new_value) VALUES ($1,'OWNER','Owner reconciled cash shift',$2)`,
    [req.user.sub, JSON.stringify(rows[0])]
  );
  res.json(rows[0]);
});

/** Owner's view: shifts with a declared/expected mismatch, oldest first. */
cashRouter.get("/shifts/discrepancies", requireRole("OWNER", "SUPER_ADMIN"), async (_req, res) => {
  const { rows } = await pool.query(`
    SELECT s.*, u.full_name AS manager_name,
           s.opening_cash + COALESCE((SELECT SUM(declared_amount) FROM cash_collections WHERE shift_id = s.id),0) AS expected_closing
    FROM cash_shifts s JOIN users u ON u.id = s.manager_id
    WHERE s.status = 'DECLARED'
    ORDER BY s.shift_date ASC
  `);
  const withDiff = rows.map(r => ({ ...r, difference: Number(r.declared_closing ?? 0) - Number(r.expected_closing) }))
                       .filter(r => Math.abs(r.difference) > 0.01);
  res.json(withDiff);
});
