import { Router } from "express";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { pool } from "../db/pool";

export const authRouter = Router();

const ACCESS_SECRET = process.env.JWT_ACCESS_SECRET!;
const REFRESH_SECRET = process.env.JWT_REFRESH_SECRET!;

// --- Register (customer self-signup; manager/owner/admin created by an
// existing admin/owner, not open self-signup) ---
authRouter.post("/register", async (req, res) => {
  const { full_name, phone, email, password } = req.body;
  const password_hash = password ? await bcrypt.hash(password, 12) : null;

  try {
    const { rows } = await pool.query(
      `INSERT INTO users (role, full_name, phone, email, password_hash)
       VALUES ('CUSTOMER', $1, $2, $3, $4)
       RETURNING id, role, full_name, phone`,
      [full_name, phone, email, password_hash]
    );
    res.status(201).json(rows[0]);
  } catch (err: any) {
    if (err.code === "23505") return res.status(409).json({ error: "Phone or email already registered" });
    throw err;
  }
});

// --- OTP request/verify would plug in here via your SMS provider (MSG91/Twilio) ---
authRouter.post("/otp/request", async (req, res) => {
  // TODO: generate OTP, store hashed+expiring in `otp_codes` table, send via SMS provider
  res.json({ message: "OTP sent" });
});

authRouter.post("/otp/verify", async (req, res) => {
  const { phone, otp } = req.body;
  // TODO: verify against stored OTP record; this is a stub showing the token issuance shape
  const { rows } = await pool.query(`SELECT id, role FROM users WHERE phone = $1`, [phone]);
  if (!rows[0]) return res.status(404).json({ error: "No account for this phone" });

  const accessToken = jwt.sign({ sub: rows[0].id, role: rows[0].role }, ACCESS_SECRET, { expiresIn: "15m" });
  const refreshToken = jwt.sign({ sub: rows[0].id }, REFRESH_SECRET, { expiresIn: "30d" });
  res.json({ accessToken, refreshToken });
});

// --- Role-check middleware, reused across every protected route ---
export function requireRole(...roles: string[]) {
  return (req: any, res: any, next: any) => {
    const header = req.headers.authorization;
    if (!header) return res.status(401).json({ error: "Missing token" });
    try {
      const payload: any = jwt.verify(header.replace("Bearer ", ""), ACCESS_SECRET);
      if (!roles.includes(payload.role)) return res.status(403).json({ error: "Forbidden for this role" });
      req.user = payload;
      next();
    } catch {
      res.status(401).json({ error: "Invalid or expired token" });
    }
  };
}
