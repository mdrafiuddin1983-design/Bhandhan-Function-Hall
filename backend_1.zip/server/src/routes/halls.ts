import { Router } from "express";
import { pool } from "../db/pool";
import { requireRole } from "./auth";

export const hallsRouter = Router();

// Public search — never trust a frontend cache; always hit this query live.
hallsRouter.get("/", async (req, res) => {
  const { city, min_capacity, event_date } = req.query;

  const { rows } = await pool.query(
    `SELECT h.*, 
            NOT EXISTS (
              SELECT 1 FROM bookings b
              WHERE b.hall_id = h.id
                AND b.event_date = $3
                AND b.booking_status IN ('TEMPORARILY_HELD','PAYMENT_PENDING','CONFIRMED')
            ) AS available_on_date
     FROM function_halls h
     WHERE h.is_active = TRUE
       AND ($1::text IS NULL OR h.city = $1)
       AND ($2::int IS NULL OR h.capacity >= $2)`,
    [city ?? null, min_capacity ?? null, event_date ?? null]
  );
  res.json(rows);
});

// Month view for the booking calendar — returns every date in that
// month that's currently unavailable (held or confirmed), so the
// frontend can grey them out without one request per day.
hallsRouter.get("/:id/availability", async (req, res) => {
  const { year, month } = req.query; // month: 1-12
  if (!year || !month) return res.status(400).json({ error: "year and month query params are required" });

  const { rows } = await pool.query(
    `SELECT event_date, booking_status FROM bookings
     WHERE hall_id = $1
       AND booking_status IN ('TEMPORARILY_HELD','PAYMENT_PENDING','CONFIRMED')
       AND date_part('year', event_date) = $2
       AND date_part('month', event_date) = $3`,
    [req.params.id, year, month]
  );
  res.json({ booked_dates: rows.map(r => r.event_date) });
});

hallsRouter.get("/:id", async (req, res) => {
  const { rows } = await pool.query(`SELECT * FROM function_halls WHERE id = $1`, [req.params.id]);
  if (!rows[0]) return res.status(404).json({ error: "Hall not found" });

  const images = await pool.query(`SELECT url, sort_order FROM hall_images WHERE hall_id = $1 ORDER BY sort_order`, [req.params.id]);
  const services = await pool.query(
    `SELECT s.name, hs.pricing_model, hs.unit_price, hs.is_optional
     FROM hall_services hs JOIN services s ON s.id = hs.service_id
     WHERE hs.hall_id = $1`,
    [req.params.id]
  );
  res.json({ ...rows[0], images: images.rows, services: services.rows });
});

// Owner-only: create a hall
hallsRouter.post("/", requireRole("OWNER", "SUPER_ADMIN"), async (req: any, res) => {
  const { name, description, address, city, capacity, base_price, amenities } = req.body;
  const { rows } = await pool.query(
    `INSERT INTO function_halls (owner_id, name, description, address, city, capacity, base_price, amenities)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`,
    [req.user.sub, name, description, address, city, capacity, base_price, amenities ?? {}]
  );
  res.status(201).json(rows[0]);
});
