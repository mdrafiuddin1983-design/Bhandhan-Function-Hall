import { Router } from "express";
import { pool } from "../db/pool";
import { requireRole } from "./auth";

export const ownerRouter = Router();

/**
 * Single summary call for the owner dashboard home screen.
 * Tenant isolation: every query is scoped to `WHERE h.owner_id = $1`
 * (the logged-in owner) — an owner can never see another owner's halls,
 * bookings, or revenue through this or any other /api/owner/* route.
 */
ownerRouter.get("/dashboard", requireRole("OWNER", "SUPER_ADMIN"), async (req: any, res) => {
  const ownerId = req.user.sub;

  const [today, upcoming, revenue, pending, cashVsOnline, cancelled] = await Promise.all([
    pool.query(
      `SELECT b.* FROM bookings b JOIN function_halls h ON h.id=b.hall_id
       WHERE h.owner_id=$1 AND b.event_date = CURRENT_DATE AND b.booking_status='CONFIRMED'`,
      [ownerId]
    ),
    pool.query(
      `SELECT b.* FROM bookings b JOIN function_halls h ON h.id=b.hall_id
       WHERE h.owner_id=$1 AND b.event_date > CURRENT_DATE AND b.booking_status='CONFIRMED'
       ORDER BY b.event_date ASC LIMIT 20`,
      [ownerId]
    ),
    pool.query(
      `SELECT date_trunc('month', p.created_at) AS month, SUM(p.amount) AS total
       FROM payments p
       JOIN bookings b ON b.id = p.booking_id
       JOIN function_halls h ON h.id = b.hall_id
       WHERE h.owner_id=$1 AND p.status='SUCCESS'
       GROUP BY 1 ORDER BY 1 DESC LIMIT 12`,
      [ownerId]
    ),
    pool.query(
      `SELECT b.id, b.event_date, b.total_amount, b.amount_paid, (b.total_amount-b.amount_paid) AS balance
       FROM bookings b JOIN function_halls h ON h.id=b.hall_id
       WHERE h.owner_id=$1 AND b.payment_status='PARTIALLY_PAID' AND b.booking_status='CONFIRMED'
       ORDER BY b.event_date ASC`,
      [ownerId]
    ),
    pool.query(
      `SELECT p.method, SUM(p.amount) AS total
       FROM payments p JOIN bookings b ON b.id=p.booking_id JOIN function_halls h ON h.id=b.hall_id
       WHERE h.owner_id=$1 AND p.status='SUCCESS'
       GROUP BY p.method`,
      [ownerId]
    ),
    pool.query(
      `SELECT COUNT(*) FROM bookings b JOIN function_halls h ON h.id=b.hall_id
       WHERE h.owner_id=$1 AND b.booking_status='CANCELLED'
         AND b.created_at > now() - interval '30 days'`,
      [ownerId]
    ),
  ]);

  res.json({
    todays_bookings: today.rows,
    upcoming_bookings: upcoming.rows,
    monthly_revenue: revenue.rows,
    outstanding_balances: pending.rows,
    payment_method_breakdown: cashVsOnline.rows,
    cancellations_last_30_days: Number(cancelled.rows[0].count),
  });
});

/**
 * Your commission ledger — every booking's platform_commission_amount,
 * whether it was actually split at the gateway (transfer_id present) or
 * is sitting unsplit because the owner hadn't finished KYC yet.
 * SUPER_ADMIN only — this is platform revenue, not any one owner's data.
 */
ownerRouter.get("/commission-ledger", requireRole("SUPER_ADMIN"), async (_req, res) => {
  const { rows } = await pool.query(`
    SELECT p.id, p.created_at, p.amount, p.platform_commission_amount, p.owner_settlement_amount,
           p.gateway_transfer_id IS NOT NULL AS auto_split_confirmed,
           h.name AS hall_name, h.owner_id, u.full_name AS owner_name
    FROM payments p
    JOIN bookings b ON b.id = p.booking_id
    JOIN function_halls h ON h.id = b.hall_id
    JOIN users u ON u.id = h.owner_id
    WHERE p.status = 'SUCCESS'
    ORDER BY p.created_at DESC
    LIMIT 200
  `);
  const totalCommission = rows.reduce((sum, r) => sum + Number(r.platform_commission_amount ?? 0), 0);
  const unsplitCount = rows.filter(r => !r.auto_split_confirmed).length;
  res.json({ payments: rows, total_commission: totalCommission, unsplit_payments_needing_manual_settlement: unsplitCount });
});
