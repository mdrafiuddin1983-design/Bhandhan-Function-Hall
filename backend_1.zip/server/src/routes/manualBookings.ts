import { Router } from "express";
import { pool } from "../db/pool";
import { requireRole } from "./auth";
import { sendNotification } from "../services/notifications";

export const manualBookingsRouter = Router();

/**
 * Manager creates a booking for a walk-in customer.
 * Deliberately reuses the EXACT same transaction shape as the customer
 * "hold" endpoint (bookings.ts) — same row lock, same EXCLUDE constraint —
 * so a manager cannot manually book a hall/date that's already confirmed
 * on the website, and vice versa. There is only ever one booking engine.
 */
manualBookingsRouter.post("/", requireRole("MANAGER"), async (req: any, res) => {
  const {
    customer_name, customer_phone, customer_email,
    hall_id, event_type_id, event_date, guest_count,
    total_amount, advance_amount, payment_method, // 'CASH' | 'BANK_TRANSFER' | 'OTHER'
  } = req.body;

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // Manager must be assigned to this hall
    const assigned = await client.query(
      `SELECT 1 FROM hall_managers WHERE hall_id = $1 AND manager_id = $2`,
      [hall_id, req.user.sub]
    );
    if (assigned.rows.length === 0) {
      await client.query("ROLLBACK");
      return res.status(403).json({ error: "You are not assigned to this hall" });
    }

    // Find or create the customer record by phone (walk-ins may not have an account yet)
    let customer = (await client.query(`SELECT id FROM users WHERE phone = $1`, [customer_phone])).rows[0];
    if (!customer) {
      customer = (
        await client.query(
          `INSERT INTO users (role, full_name, phone, email) VALUES ('CUSTOMER',$1,$2,$3) RETURNING id`,
          [customer_name, customer_phone, customer_email ?? null]
        )
      ).rows[0];
    }

    await client.query(`SELECT id FROM function_halls WHERE id = $1 FOR UPDATE`, [hall_id]);

    const { rows } = await client.query(
      `INSERT INTO bookings
         (hall_id, customer_id, event_type_id, event_date, guest_count,
          total_amount, amount_paid, booking_status, payment_status, created_by_manager_id)
       VALUES ($1,$2,$3,$4,$5,$6,0,'CONFIRMED','UNPAID',$7)
       RETURNING *`,
      [hall_id, customer.id, event_type_id, event_date, guest_count, total_amount, req.user.sub]
    );
    const booking = rows[0];

    // Record the advance right away if one was collected at the desk
    if (advance_amount > 0) {
      const payment = (
        await client.query(
          `INSERT INTO payments (booking_id, amount, method, status, recorded_by_manager_id)
           VALUES ($1,$2,$3,'SUCCESS',$4) RETURNING *`,
          [booking.id, advance_amount, payment_method, req.user.sub]
        )
      ).rows[0];

      await client.query(
        `UPDATE bookings SET amount_paid = $2,
           payment_status = CASE WHEN $2 >= total_amount THEN 'FULLY_PAID' ELSE 'PARTIALLY_PAID' END
         WHERE id = $1`,
        [booking.id, advance_amount]
      );

      if (payment_method === "CASH") {
        // Cash needs the verification trail from Section 8 — see cash.ts
        // for the OTP step; this just creates the pending record.
        await client.query(
          `INSERT INTO cash_collections (payment_id, manager_id, declared_amount)
           VALUES ($1,$2,$3)`,
          [payment.id, req.user.sub, advance_amount]
        );
      }
    }

    await client.query(
      `INSERT INTO audit_logs (user_id, role, action, booking_id, new_value)
       VALUES ($1,'MANAGER','Manager created manual booking',$2,$3)`,
      [req.user.sub, booking.id, JSON.stringify(booking)]
    );

    await client.query("COMMIT");

    await sendNotification({
      userId: customer.id,
      bookingId: booking.id,
      eventKey: "BOOKING_CONFIRMED",
      vars: { event_date, amount_paid: advance_amount ?? 0, total_amount },
    });

    res.status(201).json(booking);
  } catch (err: any) {
    await client.query("ROLLBACK");
    if (err.code === "23P01") {
      return res.status(409).json({ error: "This hall is already booked for that date." });
    }
    console.error(err);
    res.status(500).json({ error: "Could not create manual booking" });
  } finally {
    client.release();
  }
});
