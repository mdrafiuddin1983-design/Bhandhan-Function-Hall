import { Router } from "express";
import crypto from "crypto";
import Razorpay from "razorpay"; // swap for Cashfree's SDK if preferred — same shape
import { pool } from "../db/pool";
import { requireRole } from "./auth";
import { sendNotification } from "../services/notifications";

export const paymentsRouter = Router();

const razorpay = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID!,
  key_secret: process.env.RAZORPAY_KEY_SECRET!,
});

/**
 * Step 1 of the pay-to-confirm flow.
 * Customer has a TEMPORARILY_HELD booking and has chosen advance or full
 * payment on the frontend. This creates a gateway order for that amount —
 * it does NOT confirm anything. Confirmation only ever happens in the
 * webhook handler below, after the gateway itself verifies the payment.
 *
 * THE COMMISSION GUARANTEE: this order includes a Razorpay Route `transfers`
 * instruction. When the customer pays, Razorpay itself splits the money at
 * that instant — your commission share simply stays in your master
 * account, and only the owner's share is transferred to their linked
 * account. The owner and manager never hold or touch your commission; it
 * never becomes money you have to collect from them after the fact.
 * This requires the owner to have completed Route KYC first — see
 * ownerAccounts.ts. If they haven't, the order still succeeds but with
 * no transfer, and the full amount sits in your account until you settle
 * it manually — the code never sends 100% to an owner without a split.
 */
paymentsRouter.post("/create-order", requireRole("CUSTOMER"), async (req: any, res) => {
  const { booking_id, amount, pay_type } = req.body; // pay_type: 'ADVANCE' | 'FULL'

  const { rows } = await pool.query(
    `SELECT b.*, h.min_advance_percent, h.base_price, h.commission_percent_override,
            h.owner_id, opa.gateway_linked_account_id, opa.status AS payout_status
     FROM bookings b
     JOIN function_halls h ON h.id = b.hall_id
     LEFT JOIN owner_payout_accounts opa ON opa.owner_id = h.owner_id
     WHERE b.id = $1 AND b.customer_id = $2`,
    [booking_id, req.user.sub]
  );
  const booking = rows[0];
  if (!booking) return res.status(404).json({ error: "Booking not found" });
  if (!["TEMPORARILY_HELD", "PAYMENT_PENDING"].includes(booking.booking_status)) {
    return res.status(409).json({ error: "This hold has expired or the booking is no longer payable." });
  }

  const minAdvance = (booking.total_amount || booking.base_price) * (booking.min_advance_percent / 100);
  if (pay_type === "ADVANCE" && amount < minAdvance) {
    return res.status(400).json({ error: `Advance must be at least ₹${minAdvance.toFixed(0)}` });
  }

  const settingRow = await pool.query(`SELECT value FROM platform_settings WHERE key = 'default_commission_percent'`);
  const commissionPercent = Number(booking.commission_percent_override ?? settingRow.rows[0].value);
  const commissionAmount = Math.round(amount * commissionPercent) / 100;
  const ownerAmount = amount - commissionAmount;

  const canSplit = booking.payout_status === "ACTIVE" && booking.gateway_linked_account_id;

  const order = await razorpay.orders.create({
    amount: Math.round(amount * 100), // paise
    currency: "INR",
    receipt: `booking_${booking_id}`,
    notes: { booking_id, pay_type, commission_amount: commissionAmount, owner_amount: ownerAmount },
    // Route split: only the owner's portion transfers out. Your commission
    // is simply the amount that's never included in this transfers array.
    transfers: canSplit
      ? [
          {
            account: booking.gateway_linked_account_id,
            amount: Math.round(ownerAmount * 100),
            currency: "INR",
            notes: { booking_id, type: "owner_settlement" },
            on_hold: false, // pays out to the owner on Razorpay's normal payout schedule automatically
          },
        ]
      : undefined,
  });

  if (!canSplit) {
    console.warn(`Owner ${booking.owner_id} has no active payout account — commission split skipped, full amount held on platform account for manual settlement.`);
  }

  await pool.query(
    `UPDATE bookings SET booking_status = 'PAYMENT_PENDING', updated_at = now() WHERE id = $1`,
    [booking_id]
  );

  res.json({ order_id: order.id, amount: order.amount, currency: order.currency, key_id: process.env.RAZORPAY_KEY_ID });
});

/**
 * Step 2 — the ONLY place a booking is ever confirmed.
 * Razorpay calls this server-to-server; we verify the HMAC signature
 * before trusting anything in the payload. The frontend's "payment
 * succeeded" callback is for UI purposes only and is never treated
 * as proof of payment on its own.
 */
paymentsRouter.post("/webhook", async (req, res) => {
  const signature = req.headers["x-razorpay-signature"] as string;
  const expected = crypto
    .createHmac("sha256", process.env.RAZORPAY_WEBHOOK_SECRET!)
    .update(JSON.stringify(req.body))
    .digest("hex");

  if (signature !== expected) {
    return res.status(400).json({ error: "Invalid webhook signature" });
  }

  const event = req.body;
  if (event.event !== "payment.captured") {
    return res.status(200).json({ received: true }); // ignore events we don't act on
  }

  const payment = event.payload.payment.entity;
  const bookingId = payment.notes?.booking_id;
  const amount = payment.amount / 100;

  const client = await pool.connect();
  try {
    await client.query("BEGIN");

    // Idempotency: a webhook can be delivered more than once. Skip if
    // we've already recorded this exact gateway payment id.
    const existing = await client.query(`SELECT id FROM payments WHERE gateway_payment_id = $1`, [payment.id]);
    if (existing.rows.length > 0) {
      await client.query("ROLLBACK");
      return res.status(200).json({ received: true, duplicate: true });
    }

    await client.query(
      `INSERT INTO payments (booking_id, amount, method, status, gateway_payment_id, gateway_order_id, platform_commission_amount, owner_settlement_amount, gateway_transfer_id)
       VALUES ($1,$2,'ONLINE_UPI','SUCCESS',$3,$4,$5,$6,$7)`,
      [
        bookingId, amount, payment.id, payment.order_id,
        payment.notes?.commission_amount ?? null,
        payment.notes?.owner_amount ?? null,
        payment.transfer_id ?? null,
      ]
    );

    const { rows } = await client.query(
      `UPDATE bookings
       SET amount_paid = amount_paid + $2,
           booking_status = 'CONFIRMED',
           payment_status = CASE WHEN amount_paid + $2 >= total_amount THEN 'FULLY_PAID' ELSE 'PARTIALLY_PAID' END,
           updated_at = now()
       WHERE id = $1 AND booking_status IN ('TEMPORARILY_HELD','PAYMENT_PENDING')
       RETURNING *`,
      [bookingId, amount]
    );

    if (!rows[0]) {
      // Hold had already expired before payment landed — refund, don't confirm.
      await client.query("ROLLBACK");
      // TODO: trigger a refund via razorpay.payments.refund(payment.id)
      return res.status(200).json({ received: true, action: "refund_required_hold_expired" });
    }

    await client.query(
      `INSERT INTO audit_logs (action, booking_id, new_value)
       VALUES ('Payment verified via webhook, booking confirmed', $1, $2)`,
      [bookingId, JSON.stringify({ amount, gateway_payment_id: payment.id })]
    );

    await client.query("COMMIT");

    // TODO(Phase 12): also notify the assigned hall manager/owner
    await sendNotification({
      userId: rows[0].customer_id,
      bookingId: rows[0].id,
      eventKey: "BOOKING_CONFIRMED",
      vars: { event_date: rows[0].event_date, amount_paid: rows[0].amount_paid, total_amount: rows[0].total_amount },
    });

    res.status(200).json({ received: true });
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
});
