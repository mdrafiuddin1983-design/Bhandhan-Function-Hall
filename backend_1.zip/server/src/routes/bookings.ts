import { Router } from "express";
import jwt from "jsonwebtoken";
import { pool } from "../db/pool";
import { requireRole } from "./auth";
import { sendNotification } from "../services/notifications";

export const bookingsRouter = Router();

const HOLD_MINUTES = 15;
const ACCESS_SECRET = process.env.JWT_ACCESS_SECRET!;

/**
 * Guest checkout: the public website doesn't force a signup/login screen
 * before booking (matches how most consumer booking sites work) — this
 * finds-or-creates the customer by phone, then creates the hold, and
 * returns a short-lived token so the same "guest" can call the payment
 * endpoints next without a separate login step. Everything else about
 * the hold (row lock + EXCLUDE constraint) is identical to the
 * authenticated /hold route below.
 */
bookingsRouter.post("/guest-hold", async (req, res) => {
  const { full_name, phone, email, hall_id, event_date, event_type_id, guest_count } = req.body;
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    let customer = (await client.query(`SELECT id FROM users WHERE phone = $1`, [phone])).rows[0];
    if (!customer) {
      customer = (
        await client.query(
          `INSERT INTO users (role, full_name, phone, email) VALUES ('CUSTOMER',$1,$2,$3) RETURNING id`,
          [full_name, phone, email ?? null]
        )
      ).rows[0];
    }

    await client.query(`SELECT id FROM function_halls WHERE id = $1 FOR UPDATE`, [hall_id]);

    const holdExpiresAt = new Date(Date.now() + HOLD_MINUTES * 60_000);
    const { rows } = await client.query(
      `INSERT INTO bookings (hall_id, customer_id, event_type_id, event_date, guest_count, booking_status, hold_expires_at)
       VALUES ($1,$2,$3,$4,$5,'TEMPORARILY_HELD',$6) RETURNING *`,
      [hall_id, customer.id, event_type_id, event_date, guest_count, holdExpiresAt]
    );

    await client.query(
      `INSERT INTO audit_logs (user_id, role, action, booking_id, new_value)
       VALUES ($1,'CUSTOMER','Guest booking hold created',$2,$3)`,
      [customer.id, rows[0].id, JSON.stringify(rows[0])]
    );

    await client.query("COMMIT");

    const token = jwt.sign({ sub: customer.id, role: "CUSTOMER" }, ACCESS_SECRET, { expiresIn: "1h" });
    res.status(201).json({ booking: rows[0], holdExpiresInMinutes: HOLD_MINUTES, token });
  } catch (err: any) {
    await client.query("ROLLBACK");
    if (err.code === "23P01") {
      return res.status(409).json({ error: "This hall is no longer available on that date." });
    }
    console.error(err);
    res.status(500).json({ error: "Could not create hold" });
  } finally {
    client.release();
  }
});


/**
 * Create a temporary hold on hall+date.
 *
 * Safety comes from TWO independent layers, deliberately redundant:
 *  1. `SELECT ... FOR UPDATE` on the hall row serializes concurrent
 *     requests for the same hall so only one transaction proceeds at a time.
 *  2. The `no_double_booking` EXCLUDE constraint in the DB (schema.sql)
 *     makes Postgres itself reject a conflicting INSERT even if the
 *     row lock were somehow bypassed (e.g. a bug, a second DB connection
 *     pool, a future code change). This is what makes it a *guarantee*
 *     rather than "very likely fine."
 *
 * If another request already holds/confirmed this hall+date, this
 * fails cleanly with 409 — never a silent overwrite.
 */
bookingsRouter.post("/hold", requireRole("CUSTOMER", "MANAGER"), async (req: any, res) => {
  const { hall_id, event_date, event_type_id, guest_count } = req.body;
  const client = await pool.connect();

  try {
    await client.query("BEGIN");

    // Lock the hall row so concurrent requests for the SAME hall queue up
    // instead of racing (the DB constraint is the real backstop either way).
    await client.query(`SELECT id FROM function_halls WHERE id = $1 FOR UPDATE`, [hall_id]);

    const holdExpiresAt = new Date(Date.now() + HOLD_MINUTES * 60_000);

    const { rows } = await client.query(
      `INSERT INTO bookings
         (hall_id, customer_id, event_type_id, event_date, guest_count,
          booking_status, hold_expires_at)
       VALUES ($1,$2,$3,$4,$5,'TEMPORARILY_HELD',$6)
       RETURNING *`,
      [hall_id, req.user.sub, event_type_id, event_date, guest_count, holdExpiresAt]
    );

    await client.query(
      `INSERT INTO audit_logs (user_id, role, action, booking_id, new_value)
       VALUES ($1,$2,'Booking hold created',$3,$4)`,
      [req.user.sub, req.user.role, rows[0].id, JSON.stringify(rows[0])]
    );

    await client.query("COMMIT");
    res.status(201).json({ booking: rows[0], holdExpiresInMinutes: HOLD_MINUTES });
  } catch (err: any) {
    await client.query("ROLLBACK");

    // Postgres exclusion-constraint violation code
    if (err.code === "23P01") {
      return res.status(409).json({ error: "This hall is no longer available on that date." });
    }
    console.error(err);
    res.status(500).json({ error: "Could not create hold" });
  } finally {
    client.release();
  }
});

/**
 * Confirm a booking after payment gateway webhook verification.
 * NEVER call this from a frontend "payment success" callback alone —
 * only from the verified webhook handler (Phase 5). Shown here as the
 * state transition contract that Phase 5 will call into.
 */
bookingsRouter.post("/:id/confirm-after-payment", async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    const { rows } = await client.query(
      `UPDATE bookings
       SET booking_status = 'CONFIRMED',
           payment_status = CASE WHEN amount_paid >= total_amount THEN 'FULLY_PAID' ELSE 'PARTIALLY_PAID' END,
           updated_at = now()
       WHERE id = $1 AND booking_status IN ('TEMPORARILY_HELD','PAYMENT_PENDING')
       RETURNING *`,
      [req.params.id]
    );
    if (!rows[0]) {
      await client.query("ROLLBACK");
      return res.status(409).json({ error: "Booking is not in a confirmable state (hold may have expired)" });
    }
    await client.query("COMMIT");

    await sendNotification({
      userId: rows[0].customer_id,
      bookingId: rows[0].id,
      eventKey: "BOOKING_CONFIRMED",
      vars: { event_date: rows[0].event_date, amount_paid: rows[0].amount_paid, total_amount: rows[0].total_amount },
    });

    res.json(rows[0]);
  } catch (err) {
    await client.query("ROLLBACK");
    throw err;
  } finally {
    client.release();
  }
});

/**
 * Expire stale holds. Run this on a schedule (cron / pg_cron / a worker
 * queue) every minute — do not rely on it running on-demand.
 */
bookingsRouter.post("/internal/expire-holds", async (_req, res) => {
  const { rowCount } = await pool.query(
    `UPDATE bookings SET booking_status = 'EXPIRED', updated_at = now()
     WHERE booking_status = 'TEMPORARILY_HELD' AND hold_expires_at < now()`
  );
  res.json({ expired: rowCount });
});

/** Used by the website to poll for webhook-verified confirmation after checkout. */
bookingsRouter.get("/:id", requireRole("CUSTOMER", "MANAGER", "OWNER", "SUPER_ADMIN"), async (req: any, res) => {
  const { rows } = await pool.query(`SELECT * FROM bookings WHERE id = $1`, [req.params.id]);
  const booking = rows[0];
  if (!booking) return res.status(404).json({ error: "Not found" });
  if (req.user.role === "CUSTOMER" && booking.customer_id !== req.user.sub) {
    return res.status(403).json({ error: "Not your booking" });
  }
  res.json(booking);
});
