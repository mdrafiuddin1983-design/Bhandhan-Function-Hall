import cron from "node-cron";
import { pool } from "../db/pool";
import { sendNotification } from "../services/notifications";

/**
 * Runs daily. Finds CONFIRMED bookings that are PARTIALLY_PAID and sends a
 * balance-due reminder to the customer at fixed milestones before the event
 * (14/7/3/1 days out — tune freely). The owner does NOT need to chase this
 * manually for it to happen, but nothing here stops them from doing so too —
 * this is a safety net, not a replacement for the owner's own judgment about
 * a specific customer/relationship (per your note: this is normal in the
 * industry and owners often handle it themselves).
 *
 * Idempotency: the DB's partial unique index on
 * notifications(booking_id, event_key, channel) means re-running this job,
 * or running two instances by accident, can never double-send the same
 * milestone reminder.
 */
const REMINDER_DAYS_BEFORE = [14, 7, 3, 1];

export function startBalanceReminderJob() {
  cron.schedule("0 9 * * *", runBalanceReminders); // every day at 9am server time
}

export async function runBalanceReminders() {
  for (const daysBefore of REMINDER_DAYS_BEFORE) {
    const { rows: dueBookings } = await pool.query(
      `SELECT b.*, h.name AS hall_name, h.owner_id
       FROM bookings b
       JOIN function_halls h ON h.id = b.hall_id
       WHERE b.booking_status = 'CONFIRMED'
         AND b.payment_status = 'PARTIALLY_PAID'
         AND b.event_date = (CURRENT_DATE + $1::int)`,
      [daysBefore]
    );

    for (const booking of dueBookings) {
      const balance = Number(booking.total_amount) - Number(booking.amount_paid);
      if (balance <= 0) continue;

      const eventKey = `BALANCE_REMINDER_${daysBefore}D`; // distinct milestone = distinct dedupe key

      // Customer: mobile push + WhatsApp + SMS + email, per the requirement
      // that this reaches them everywhere, not just one channel.
      await sendNotification({
        userId: booking.customer_id,
        bookingId: booking.id,
        eventKey,
        channels: ["PUSH", "WHATSAPP", "SMS", "EMAIL"],
        vars: {
          hall_name: booking.hall_name,
          event_date: booking.event_date,
          balance_amount: balance.toFixed(0),
          days_before: daysBefore,
        },
      });

      // Owner: a lighter heads-up (push + email is enough) so they can step
      // in personally if they'd rather handle this particular customer
      // themselves — automated reminders don't take that option away.
      await sendNotification({
        userId: booking.owner_id,
        bookingId: booking.id,
        eventKey: `${eventKey}_OWNER_NOTICE`,
        channels: ["PUSH", "EMAIL"],
        vars: {
          hall_name: booking.hall_name,
          event_date: booking.event_date,
          balance_amount: balance.toFixed(0),
          days_before: daysBefore,
          customer_id: booking.customer_id,
        },
      });
    }
  }
}
