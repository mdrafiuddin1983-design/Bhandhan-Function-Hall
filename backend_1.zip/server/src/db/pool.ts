import { Pool } from "pg";

// One shared connection pool. Every write that touches booking state
// MUST go through pool.connect() + explicit transaction (see bookings.ts) —
// never pool.query() directly for booking writes, or you lose the
// transaction boundary that makes zero-double-booking possible.
export const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});
