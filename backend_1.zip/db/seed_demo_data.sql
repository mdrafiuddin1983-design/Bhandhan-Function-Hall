-- Minimal real data so the website isn't just talking to an empty database.
-- Uses fixed UUIDs so the website config can reference them directly.

INSERT INTO users (id, role, full_name, phone, email) VALUES
  ('11111111-1111-1111-1111-111111111111', 'OWNER', 'Bandhan Hall Owner', '9000000001', 'owner@bandhanfunctionhall.example')
ON CONFLICT (id) DO NOTHING;

INSERT INTO function_halls (id, owner_id, name, description, address, city, capacity, base_price, min_advance_percent) VALUES
  ('22222222-2222-2222-2222-222222222222', '11111111-1111-1111-1111-111111111111',
   'Bandhan Function Hall', 'AC banquet hall for weddings, receptions and celebrations.',
   '[street address], Hyderabad', 'Hyderabad', 500, 80000, 30)
ON CONFLICT (id) DO NOTHING;

INSERT INTO event_types (id, name) VALUES
  ('33333333-3333-3333-3333-333333333331', 'Wedding'),
  ('33333333-3333-3333-3333-333333333332', 'Engagement'),
  ('33333333-3333-3333-3333-333333333333', 'Reception'),
  ('33333333-3333-3333-3333-333333333334', 'Birthday'),
  ('33333333-3333-3333-3333-333333333335', 'Anniversary'),
  ('33333333-3333-3333-3333-333333333336', 'Corporate event')
ON CONFLICT (id) DO NOTHING;

-- A demo customer, in case you want to test the manager-side manual booking flow too.
INSERT INTO users (id, role, full_name, phone, email) VALUES
  ('44444444-4444-4444-4444-444444444444', 'CUSTOMER', 'Test Customer', '9000000002', 'customer@example.com')
ON CONFLICT (id) DO NOTHING;
