-- =========================================================
-- Function Hall Booking Platform — Phase 1-4 core schema
-- PostgreSQL 14+ (needs btree_gist for the EXCLUDE constraint)
-- =========================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "btree_gist";

-- ---------- Users & roles ----------
CREATE TYPE user_role AS ENUM ('CUSTOMER', 'MANAGER', 'OWNER', 'SUPER_ADMIN');

CREATE TABLE users (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    role            user_role NOT NULL,
    full_name       TEXT NOT NULL,
    phone           TEXT UNIQUE NOT NULL,
    email           TEXT UNIQUE,
    password_hash   TEXT,                 -- null if OTP-only login
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Owners / Halls / Managers ----------
CREATE TABLE function_halls (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id        UUID NOT NULL REFERENCES users(id),
    name            TEXT NOT NULL,
    description     TEXT,
    address         TEXT NOT NULL,
    city            TEXT NOT NULL,
    lat             NUMERIC(9,6),
    lng             NUMERIC(9,6),
    capacity        INT NOT NULL,
    is_ac           BOOLEAN NOT NULL DEFAULT TRUE,
    parking_capacity INT DEFAULT 0,
    amenities       JSONB NOT NULL DEFAULT '{}',  -- {generator: true, wifi: true, ...}
    base_price      NUMERIC(12,2) NOT NULL,
    min_advance_percent NUMERIC(5,2) NOT NULL DEFAULT 30.00, -- owner-configurable; booking cannot be CONFIRMED with less than this % paid
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Owner payout accounts (Section 21 settlement) ----------
-- An owner cannot receive any split payout until they complete the
-- gateway's own KYC (Razorpay Route "linked account" / Cashfree "vendor").
-- This is what makes the commission split automatic and untouchable by
-- the owner/manager: the gateway itself divides the money at the moment
-- the customer pays, before it ever reaches the owner's bank.
CREATE TYPE payout_account_status AS ENUM ('NOT_STARTED', 'PENDING_KYC', 'ACTIVE', 'REJECTED');

CREATE TABLE owner_payout_accounts (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id                UUID NOT NULL REFERENCES users(id) UNIQUE,
    gateway_linked_account_id TEXT,           -- e.g. Razorpay "acc_..." once approved
    status                  payout_account_status NOT NULL DEFAULT 'NOT_STARTED',
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Platform commission settings ----------
CREATE TABLE platform_settings (
    key         TEXT PRIMARY KEY,
    value       JSONB NOT NULL
);
INSERT INTO platform_settings (key, value) VALUES ('default_commission_percent', '5.0');
-- Per-hall override, if you ever want a different rate for a specific hall/owner:
ALTER TABLE function_halls ADD COLUMN commission_percent_override NUMERIC(5,2);

CREATE TABLE hall_managers (
    hall_id     UUID NOT NULL REFERENCES function_halls(id),
    manager_id  UUID NOT NULL REFERENCES users(id),
    PRIMARY KEY (hall_id, manager_id)
);

CREATE TABLE hall_images (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    hall_id     UUID NOT NULL REFERENCES function_halls(id) ON DELETE CASCADE,
    url         TEXT NOT NULL,
    sort_order  INT NOT NULL DEFAULT 0
);

-- ---------- Services / pricing ----------
CREATE TYPE pricing_model AS ENUM ('FIXED', 'PER_PERSON', 'PER_TABLE', 'PER_CHAIR', 'PER_HOUR', 'PERCENTAGE', 'INCLUDED');

CREATE TABLE services (
    id      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name    TEXT UNIQUE NOT NULL      -- Decoration, Catering, DJ, Photography...
);

CREATE TABLE hall_services (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    hall_id         UUID NOT NULL REFERENCES function_halls(id) ON DELETE CASCADE,
    service_id      UUID NOT NULL REFERENCES services(id),
    pricing_model   pricing_model NOT NULL,
    unit_price      NUMERIC(12,2) NOT NULL DEFAULT 0,
    is_optional     BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE (hall_id, service_id)
);

-- ---------- Event types ----------
CREATE TABLE event_types (
    id      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name    TEXT UNIQUE NOT NULL      -- Wedding, Nikah, Birthday, Corporate...
);

-- ---------- Bookings (the critical table) ----------
CREATE TYPE booking_status AS ENUM (
    'TEMPORARILY_HELD', 'PAYMENT_PENDING', 'CONFIRMED',
    'CANCELLED', 'EXPIRED', 'COMPLETED', 'BLOCKED_BY_OWNER'
);
CREATE TYPE payment_status AS ENUM ('UNPAID', 'PARTIALLY_PAID', 'FULLY_PAID', 'REFUNDED');
CREATE TYPE cash_verification_status AS ENUM ('NOT_APPLICABLE', 'RECORDED', 'CUSTOMER_VERIFIED', 'DEPOSITED', 'RECONCILED');
CREATE TYPE settlement_status AS ENUM ('PENDING', 'PROCESSING', 'SETTLED', 'ON_HOLD');
CREATE TYPE event_status AS ENUM ('UPCOMING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED');

CREATE TABLE bookings (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    hall_id                 UUID NOT NULL REFERENCES function_halls(id),
    customer_id             UUID NOT NULL REFERENCES users(id),
    event_type_id           UUID NOT NULL REFERENCES event_types(id),
    event_date              DATE NOT NULL,
    guest_count             INT NOT NULL,
    total_amount            NUMERIC(12,2) NOT NULL DEFAULT 0,
    amount_paid             NUMERIC(12,2) NOT NULL DEFAULT 0,

    booking_status          booking_status NOT NULL DEFAULT 'TEMPORARILY_HELD',
    payment_status          payment_status NOT NULL DEFAULT 'UNPAID',
    cash_verification_status cash_verification_status NOT NULL DEFAULT 'NOT_APPLICABLE',
    settlement_status       settlement_status NOT NULL DEFAULT 'PENDING',
    event_status            event_status NOT NULL DEFAULT 'UPCOMING',

    hold_expires_at         TIMESTAMPTZ,          -- only set while TEMPORARILY_HELD
    created_by_manager_id   UUID REFERENCES users(id),  -- set for manual bookings
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now(),

    -- THE ZERO-DOUBLE-BOOKING GUARANTEE:
    -- Postgres itself refuses a second overlapping row for the same hall+date
    -- while status is "live" (held/pending/confirmed) — enforced by the DB,
    -- not by application logic, so it holds even under concurrent requests
    -- or an application bug.
    CONSTRAINT no_double_booking
        EXCLUDE USING gist (
            hall_id WITH =,
            daterange(event_date, event_date, '[]') WITH &&
        )
        WHERE (booking_status IN ('TEMPORARILY_HELD', 'PAYMENT_PENDING', 'CONFIRMED'))
);

CREATE INDEX idx_bookings_hall_date ON bookings (hall_id, event_date);
CREATE INDEX idx_bookings_customer ON bookings (customer_id);

CREATE TABLE booking_services (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id  UUID NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
    hall_service_id UUID NOT NULL REFERENCES hall_services(id),
    quantity    INT NOT NULL DEFAULT 1,
    line_amount NUMERIC(12,2) NOT NULL
);

-- ---------- Payments ----------
CREATE TYPE payment_method AS ENUM ('ONLINE_UPI', 'ONLINE_CARD', 'ONLINE_NETBANKING', 'ONLINE_WALLET', 'CASH', 'BANK_TRANSFER', 'OTHER');
CREATE TYPE payment_txn_status AS ENUM ('INITIATED', 'SUCCESS', 'FAILED', 'REFUNDED');

CREATE TABLE payments (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    booking_id          UUID NOT NULL REFERENCES bookings(id),
    amount              NUMERIC(12,2) NOT NULL,
    method              payment_method NOT NULL,
    status              payment_txn_status NOT NULL DEFAULT 'INITIATED',
    gateway_payment_id  TEXT,           -- e.g. Razorpay payment id
    gateway_order_id    TEXT,
    platform_commission_amount NUMERIC(12,2),  -- what the split sent to YOUR account
    owner_settlement_amount    NUMERIC(12,2),  -- what the split sent to the owner's linked account
    gateway_transfer_id        TEXT,           -- Razorpay Route transfer id for the owner's share
    recorded_by_manager_id UUID REFERENCES users(id),  -- set for manual/cash entries
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE cash_collections (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    payment_id          UUID NOT NULL REFERENCES payments(id),
    manager_id          UUID NOT NULL REFERENCES users(id),
    otp_verified        BOOLEAN NOT NULL DEFAULT FALSE,
    otp_code_hash       TEXT,
    otp_expires_at      TIMESTAMPTZ,
    deposited_at        TIMESTAMPTZ,
    reconciled_at        TIMESTAMPTZ,
    declared_amount     NUMERIC(12,2),
    expected_amount     NUMERIC(12,2),
    device_info         JSONB,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ---------- Cash shifts (Section 9 reconciliation) ----------
CREATE TYPE cash_shift_status AS ENUM ('OPEN', 'DECLARED', 'RECONCILED', 'DISPUTED');

CREATE TABLE cash_shifts (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    manager_id          UUID NOT NULL REFERENCES users(id),
    hall_id             UUID NOT NULL REFERENCES function_halls(id),
    shift_date          DATE NOT NULL,
    opening_cash        NUMERIC(12,2) NOT NULL DEFAULT 0,
    declared_closing    NUMERIC(12,2),          -- what the manager says they're handing over
    -- expected_closing is NOT stored: it's always computed live as
    -- opening_cash + SUM(cash payments recorded during this shift),
    -- so it can never silently drift from the actual payment records.
    status              cash_shift_status NOT NULL DEFAULT 'OPEN',
    reconciled_by       UUID REFERENCES users(id),  -- owner/admin who reviewed it
    reconciled_at       TIMESTAMPTZ,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (manager_id, hall_id, shift_date)
);

-- Link each cash payment to the shift it was collected in
ALTER TABLE cash_collections ADD COLUMN shift_id UUID REFERENCES cash_shifts(id);

-- ---------- Notifications (Section 14) ----------
CREATE TYPE notification_channel AS ENUM ('PUSH', 'WHATSAPP', 'SMS', 'EMAIL');
CREATE TYPE notification_status AS ENUM ('PENDING', 'SENT', 'FAILED', 'SKIPPED_NO_CONTACT');

CREATE TABLE notification_templates (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    event_key   TEXT NOT NULL,            -- e.g. 'BOOKING_CONFIRMED', 'BALANCE_REMINDER'
    channel     notification_channel NOT NULL,
    subject     TEXT,                     -- used for email only
    body        TEXT NOT NULL,            -- supports {{placeholders}}
    is_active   BOOLEAN NOT NULL DEFAULT TRUE,
    UNIQUE (event_key, channel)
);

CREATE TABLE notifications (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID NOT NULL REFERENCES users(id),
    booking_id      UUID REFERENCES bookings(id),
    event_key       TEXT NOT NULL,
    channel         notification_channel NOT NULL,
    status          notification_status NOT NULL DEFAULT 'PENDING',
    provider_message_id TEXT,
    error_message   TEXT,
    sent_at         TIMESTAMPTZ,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notifications_booking ON notifications (booking_id, event_key);

-- Prevents sending the same reminder twice for the same booking+milestone
-- (e.g. "7 days before event") even if the reminder job runs more than once.
CREATE UNIQUE INDEX idx_notifications_dedupe
    ON notifications (booking_id, event_key, channel)
    WHERE status IN ('SENT', 'PENDING');

-- ---------- Audit log (append-only, never deleted) ----------
CREATE TABLE audit_logs (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         UUID REFERENCES users(id),
    role            user_role,
    action          TEXT NOT NULL,
    booking_id      UUID REFERENCES bookings(id),
    previous_value  JSONB,
    new_value       JSONB,
    device_info     JSONB,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
