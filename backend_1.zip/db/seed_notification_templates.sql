-- Default notification templates for the events wired in Phase 5-7.
-- Edit freely — admins can also manage these via a future admin UI (Section 28).

INSERT INTO notification_templates (event_key, channel, subject, body) VALUES
('BOOKING_CONFIRMED', 'WHATSAPP', NULL,
 'Your booking at Bandhan Function Hall for {{event_date}} is CONFIRMED. Amount paid: ₹{{amount_paid}} of ₹{{total_amount}}. Thank you!'),
('BOOKING_CONFIRMED', 'SMS', NULL,
 'Booking confirmed for {{event_date}}. Paid Rs.{{amount_paid}} of Rs.{{total_amount}}. - Bandhan Function Hall'),
('BOOKING_CONFIRMED', 'EMAIL', 'Your booking is confirmed — {{event_date}}',
 'Hi, your booking for {{event_date}} at Bandhan Function Hall is confirmed. Amount paid: ₹{{amount_paid}} of ₹{{total_amount}}. We look forward to hosting your event.'),
('BOOKING_CONFIRMED', 'PUSH', NULL,
 'Booking confirmed for {{event_date}}!'),

('BALANCE_REMINDER_14D', 'WHATSAPP', NULL,
 'Reminder: your event at {{hall_name}} is on {{event_date}} ({{days_before}} days away). Balance due: ₹{{balance_amount}}. Reply here or call us to pay.'),
('BALANCE_REMINDER_14D', 'SMS', NULL,
 'Reminder: Rs.{{balance_amount}} balance due for your {{event_date}} booking at {{hall_name}}.'),
('BALANCE_REMINDER_14D', 'EMAIL', 'Balance due for your {{event_date}} event',
 'Hi, a friendly reminder that ₹{{balance_amount}} is still due for your booking at {{hall_name}} on {{event_date}}.'),
('BALANCE_REMINDER_14D', 'PUSH', NULL, 'Balance of ₹{{balance_amount}} due for your {{event_date}} event'),

('BALANCE_REMINDER_7D', 'WHATSAPP', NULL,
 'Your event at {{hall_name}} is in {{days_before}} days ({{event_date}}). Balance due: ₹{{balance_amount}}.'),
('BALANCE_REMINDER_7D', 'SMS', NULL,
 'Rs.{{balance_amount}} balance due, event on {{event_date}} at {{hall_name}}.'),
('BALANCE_REMINDER_7D', 'EMAIL', 'Balance due — {{days_before}} days to go',
 'Hi, your event at {{hall_name}} is {{days_before}} days away. Balance due: ₹{{balance_amount}}.'),
('BALANCE_REMINDER_7D', 'PUSH', NULL, '{{days_before}} days to go — balance of ₹{{balance_amount}} due'),

('BALANCE_REMINDER_3D', 'WHATSAPP', NULL,
 'Only {{days_before}} days left! Balance of ₹{{balance_amount}} is due for your event at {{hall_name}} on {{event_date}}.'),
('BALANCE_REMINDER_3D', 'SMS', NULL,
 'Only {{days_before}} days left. Rs.{{balance_amount}} due for {{event_date}} booking.'),
('BALANCE_REMINDER_3D', 'EMAIL', 'Only {{days_before}} days left — balance due',
 'Hi, your event at {{hall_name}} is in {{days_before}} days. Please clear the balance of ₹{{balance_amount}} soon.'),
('BALANCE_REMINDER_3D', 'PUSH', NULL, 'Only {{days_before}} days left — ₹{{balance_amount}} due'),

('BALANCE_REMINDER_1D', 'WHATSAPP', NULL,
 'Tomorrow is the big day! Please clear the remaining ₹{{balance_amount}} for your event at {{hall_name}}.'),
('BALANCE_REMINDER_1D', 'SMS', NULL,
 'Event tomorrow. Rs.{{balance_amount}} balance still due at {{hall_name}}.'),
('BALANCE_REMINDER_1D', 'EMAIL', 'Tomorrow''s the day — balance still due',
 'Hi, your event at {{hall_name}} is tomorrow. A balance of ₹{{balance_amount}} is still due — please settle before arrival if possible.'),
('BALANCE_REMINDER_1D', 'PUSH', NULL, 'Event tomorrow — ₹{{balance_amount}} balance still due'),

-- Lighter heads-up to the owner at each milestone — informational only,
-- doesn't ask them to do anything, just keeps them in the loop so they can
-- choose to call the customer personally if they want to.
('BALANCE_REMINDER_14D_OWNER_NOTICE', 'EMAIL', 'Balance still pending — {{event_date}}',
 'Customer for the {{event_date}} booking still has ₹{{balance_amount}} outstanding ({{days_before}} days out). An automated reminder has been sent to them.'),
('BALANCE_REMINDER_7D_OWNER_NOTICE', 'EMAIL', 'Balance still pending — {{event_date}}',
 'Customer for the {{event_date}} booking still has ₹{{balance_amount}} outstanding ({{days_before}} days out). An automated reminder has been sent to them.'),
('BALANCE_REMINDER_3D_OWNER_NOTICE', 'EMAIL', 'Balance still pending — {{event_date}}',
 'Customer for the {{event_date}} booking still has ₹{{balance_amount}} outstanding ({{days_before}} days out). You may want to follow up personally.'),
('BALANCE_REMINDER_1D_OWNER_NOTICE', 'EMAIL', 'Balance still pending — event is tomorrow',
 'Customer for tomorrow''s ({{event_date}}) booking still has ₹{{balance_amount}} outstanding. You may want to follow up personally before the event.');
